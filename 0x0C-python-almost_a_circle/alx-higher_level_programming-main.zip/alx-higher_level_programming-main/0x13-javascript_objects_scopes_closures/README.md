0x13 - javascript_objects_scopes_closures;
