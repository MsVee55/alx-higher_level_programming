#!/usr/bin/python3
"""
This is a Rectangle class.
"""


class Rectangle:
    """
    Create an empty Rectangle Object.
    """
    pass
