-- script that lists all rows of the table first_table from the database
SELECT * FROM first_table;
