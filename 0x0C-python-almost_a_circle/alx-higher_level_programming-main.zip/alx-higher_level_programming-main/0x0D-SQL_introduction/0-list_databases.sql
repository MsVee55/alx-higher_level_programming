-- script for lists all databases in MySQL server
SHOW DATABASES;
