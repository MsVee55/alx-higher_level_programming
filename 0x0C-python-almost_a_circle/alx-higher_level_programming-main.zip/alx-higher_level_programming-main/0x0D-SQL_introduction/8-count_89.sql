-- script that displays the number of records with id = 89 in the table first_table of the database 
SELECT COUNT(id) FROM first_table WHERE id=89;
