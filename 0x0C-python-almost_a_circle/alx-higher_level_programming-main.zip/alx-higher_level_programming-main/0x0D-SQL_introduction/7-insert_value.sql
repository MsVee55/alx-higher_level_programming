-- script that inserts a new row in the table first_table (database hbtn_0c_0) in your MySQL server.
INSERT INTO first_table VALUES (89, 'Best School');
