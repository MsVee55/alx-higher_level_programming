-- script that lists all records of the table second_table ordered by score
SELECT score, name FROM second_table ORDER BY score DESC;
