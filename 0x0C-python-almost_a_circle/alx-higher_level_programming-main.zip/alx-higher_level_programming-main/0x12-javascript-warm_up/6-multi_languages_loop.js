#!/usr/bin/node
const myArray = ['C is fun', 'Python is cool', 'JavaScript is amazing'];

for (let i = 0, len = myArray.length; i < len; i++) {
  console.log(myArray[i]);
}
