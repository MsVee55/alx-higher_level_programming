#!/usr/bin/node
exports.addMeMaybe = function (var1, callback) {
  var1 = var1 + 1;
  callback(var1);
};
