#!/usr/bin/python3
a = 89
b = 10
b, a = a, b
print("a={:d} - b={:d}".format(a, b))
